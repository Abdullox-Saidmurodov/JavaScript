var swiper = new Swiper(".mySwiper", {
    pagination: {
      el: ".swiper-pagination",
    },
  });

  let btn = document.querySelector('#search');

  function openMenu() {
    btn.innerHTML = /*`<i class='bx bx-window-close'></i>`*/`<i class="fa-solid fa-xmark"></i>`;
  }

  let lines = document.querySelector('#lines');

  function menu() {
    if(lines.innerHTML == `<i class="fa-solid fa-xmark"></i>`){
      lines.innerHTML = `
      <div></div>
      <div></div>
      <div></div>
      `
    } else
    lines.innerHTML = `<i class="fa-solid fa-xmark"></i>`;
  }